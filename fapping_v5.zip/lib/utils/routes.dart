class MyRoutes {
  static String welcomeRoute = "/welcome";
  static String fapRoute = "/fap";
}
